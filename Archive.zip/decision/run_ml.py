from decision.pipeline import DecisionPipeline

results = DecisionPipeline().run_ml()
print(results)